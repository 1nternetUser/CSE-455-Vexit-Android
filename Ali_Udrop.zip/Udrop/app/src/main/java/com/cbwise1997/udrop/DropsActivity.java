package com.cbwise1997.udrop;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class DropsActivity extends AppCompatActivity {

    // Member Variables
    private Button mHomepageBtn;
    private Button openUdropMapBtn;


    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drops);

        mHomepageBtn = findViewById(R.id.dropsHomepage_Btn);
        openUdropMapBtn = findViewById(R.id.startUdropMap_Btn);

        mHomepageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openHomepageActivity();
            }
        });

        openUdropMapBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMainActivity();
            }
        });
    }

    private void openHomepageActivity(){
        Intent intent = new Intent(DropsActivity.this, HomepageActivity.class);
        finish();
        startActivity(intent);
    }

    private void openMainActivity(){
        Intent intent = new Intent(DropsActivity.this, MainActivity.class);
        finish();
        startActivity(intent);
    }
}
