package com.cbwise1997.udrop;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class FriendsActivity extends AppCompatActivity {

    // Constants
    // IF ONE CONSTANT IS CHANGED IT MUST BE CHANGED IN EACH JAVA CLASS (trying to figure out a way to fix this)
    private String PROFILE_PREFS = "ProfilePrefs";

    private String USER_ID_KEY = "UserIDKey";
    private String FIRST_NAME_KEY = "FirstNameKey";
    private String LAST_NAME_KEY = "LastNameKey";
    private String NICKNAME_KEY = "NicknameKey";
    private String EMAIL_KEY = "EmailKey";
    private String PHONE_KEY = "PhoneKey";

    // Member Variables
    private Button mAddFriendBtn;
    private Button mHomepageBtn;
    private EditText mFriendEmailET;

    private DatabaseReference mDatabaseReference;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friends);

        // Assigning member variables

        mAddFriendBtn = findViewById(R.id.friendsAddFriend_Btn);
        mHomepageBtn = findViewById(R.id.friendsHomepage_Btn);
        mFriendEmailET = findViewById(R.id.friendsEmail_ET);

        mDatabaseReference = FirebaseDatabase.getInstance().getReference("users/cbwise/friends");

        // On click listeners

        mAddFriendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addFriend();
            }
        });

        mHomepageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openHomepageActivity();
            }
        });
    }

    private void addFriend() {
        String email = mFriendEmailET.getText().toString().trim();
        if(!email.isEmpty() && email.contains("@")){
            String id = mDatabaseReference.push().getKey();
            UserInfo userInfo = new UserInfo("bill","hill","bh",email,"1234567890");
            mDatabaseReference.child(id).setValue(userInfo);
            mFriendEmailET.setText("");
            Toast.makeText(this,"adding friend",Toast.LENGTH_SHORT).show();
        }
    }

    private void openHomepageActivity() {
        Intent intent = new Intent(FriendsActivity.this, HomepageActivity.class);
        finish();
        startActivity(intent);
    }
}
