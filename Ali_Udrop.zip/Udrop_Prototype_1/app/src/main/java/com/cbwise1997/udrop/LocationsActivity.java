package com.cbwise1997.udrop;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class LocationsActivity extends AppCompatActivity {

    // Constants

    // Member Variables

    private Button mHomepageBtn;
    private Button mAddLocationBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_locations);

        // Assign values to member variables
        mHomepageBtn = findViewById(R.id.locationsHomepage_Btn);
        mAddLocationBtn = findViewById(R.id.locationsAddNew_Btn);

        // On click listeners
        mHomepageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openHomepageActivity();
            }
        });
    }

    private void openHomepageActivity(){
        Intent intent = new Intent(LocationsActivity.this,HomepageActivity.class);
        finish();
        startActivity(intent);
    }
}
