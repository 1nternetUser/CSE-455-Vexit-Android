package com.cbwise1997.udrop;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import android.location.LocationManager;

import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;

import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.model.PlaceLikelihood;
import com.google.android.libraries.places.api.net.FindCurrentPlaceRequest;
import com.google.android.libraries.places.api.net.FindCurrentPlaceResponse;
import com.google.android.libraries.places.api.net.PlacesClient;

import java.util.Arrays;
import java.util.List;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.content.Context;

import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.libraries.places.api.Places;

public class MainActivity extends FragmentActivity implements OnMapReadyCallback {

    private Button mHomepageBtn;
    private GoogleMap mMap;

    private FirebaseAuth mAuth;


    // Create a new Places client instance.
//    PlacesClient placesClient = Places.createClient(this);

    /**
     * An activity that displays a map showing the place at the device's current location.
     */

    // I ADDED STATIC TO THIS CLASS, IS IT GOOD?!?
    public static class MapsActivityCurrentPlace extends AppCompatActivity
            implements OnMapReadyCallback {

        private static final String TAG = MapsActivityCurrentPlace.class.getSimpleName();
        private GoogleMap mMap;
        private CameraPosition mCameraPosition;

        // The entry point to the Places API.
        private PlacesClient mPlacesClient;

        // The entry point to the Fused Location Provider.
        private FusedLocationProviderClient mFusedLocationProviderClient;

        // A default location (Sydney, Australia) and default zoom to use when location permission is
        // not granted.
        private final LatLng mDefaultLocation = new LatLng(-33.8523341, 151.2106085);
        private static final int DEFAULT_ZOOM = 15;
        private static final int PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION = 1;
        private boolean mLocationPermissionGranted;

        // The geographical location where the device is currently located. That is, the last-known
        // location retrieved by the Fused Location Provider.
        private Location mLastKnownLocation;

        // Keys for storing activity state.
        private static final String KEY_CAMERA_POSITION = "camera_position";
        private static final String KEY_LOCATION = "location";

        // Used for selecting the current place.
        private static final int M_MAX_ENTRIES = 5;
        private String[] mLikelyPlaceNames;
        private String[] mLikelyPlaceAddresses;
        private List[] mLikelyPlaceAttributions;
        private LatLng[] mLikelyPlaceLatLngs;
        private Button mHomepageBtn;

        @Override
        public void onMapReady(GoogleMap googleMap) {

        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        mHomepageBtn = findViewById(R.id.dropsHomepage_Btn);
        mHomepageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openHomepageActivity();
            }
        });

        /*
       super.onCreate(savedInstanceState);
       setContentView(R.layout.activity_main);


        // Construct a FusedLocationProviderClient.
           mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
   */
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
        LatLng sydney = new LatLng(-34, 151);
        mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {

            @Override
            public void onMapClick(LatLng position) {
                mMap.clear();
                mMap.addMarker(new MarkerOptions().position(position));
                double longitude = position.longitude;
                double latitude = +position.latitude;
                Toast.makeText(getApplicationContext(),longitude +" : "+ latitude,Toast.LENGTH_SHORT).show();

            }
        });
    }

    private void openHomepageActivity() {
        Intent intent = new Intent(MainActivity.this, HomepageActivity.class);
        finish();
        startActivity(intent);
    }

}
/*
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d("Udrop","made it here");
        openHomepageActivity();
        Log.d("Udrop","made it here2");
    }

    private void openHomepageActivity(){
        Intent intent = new Intent(MainActivity.this, HomepageActivity.class);
        finish();
        startActivity(intent);
    }
}


 */