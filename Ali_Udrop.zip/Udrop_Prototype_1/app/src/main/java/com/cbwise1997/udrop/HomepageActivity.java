package com.cbwise1997.udrop;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;

public class HomepageActivity extends AppCompatActivity {

    // Constants
    // IF ONE CONSTANT IS CHANGED IT MUST BE CHANGED IN EACH JAVA CLASS (trying to figure out a way to fix this)
    private String PROFILE_PREFS = "ProfilePrefs";

    private String USER_ID_KEY = "UserIDKey";
    private String FIRST_NAME_KEY = "FirstNameKey";
    private String LAST_NAME_KEY = "LastNameKey";
    private String NICKNAME_KEY = "NicknameKey";
    private String EMAIL_KEY = "EmailKey";
    private String PHONE_KEY = "PhoneKey";

    // Member Variables

    private Button mLoginActivityBtn;
    private Button mDropsBtn;
    private Button mFriendsBtn;
    private Button mProfileBtn;
    private Button mLocationsBtn;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);

        // Assign member variable values

        mLoginActivityBtn= findViewById(R.id.homepageLoginActivity_Btn);
        mDropsBtn = findViewById(R.id.homepageDrops_Btn);
        mFriendsBtn = findViewById(R.id.homepageFriends_Btn);
        mProfileBtn = findViewById(R.id.homepageProfile_Btn);
        mLocationsBtn = findViewById(R.id.homepageLocations_Btn);

        mAuth = FirebaseAuth.getInstance();

        // On click listeners

        mLoginActivityBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLoginActivity();
            }
        });

        mProfileBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openProfileActivity();
            }
        });

        mFriendsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFriendsActivity();
            }
        });

        mDropsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDropsActivity();
            }
        });

        mLocationsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLocationsActivity();
            }
        });
    }

    // open new activity functions

    private void openProfileActivity(){
        Intent profileActivity = new Intent(this, ProfileActivity.class);
        finish();
        startActivity(profileActivity);
    }

    private void openFriendsActivity(){
        Intent friendsActivity = new Intent(this, FriendsActivity.class);
        finish();
        startActivity(friendsActivity);
    }

    private void openDropsActivity(){
        Intent dropsActivity = new Intent(this,DropsActivity.class);
        finish();
        startActivity(dropsActivity);
    }

    private void openLocationsActivity(){
        Intent locationsActivity = new Intent(this, LocationsActivity.class);
        finish();
        startActivity(locationsActivity);
    }

    private void openLoginActivity(){
        Intent dropsActivity = new Intent(this,LoginActivity.class);
        finish();
        startActivity(dropsActivity);
    }
}