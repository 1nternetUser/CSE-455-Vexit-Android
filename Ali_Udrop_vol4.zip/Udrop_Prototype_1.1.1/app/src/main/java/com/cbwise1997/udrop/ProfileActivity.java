package com.cbwise1997.udrop;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ProfileActivity extends AppCompatActivity {

    // Constants
    // IF ONE CONSTANT IS CHANGED IT MUST BE CHANGED IN EACH JAVA CLASS (trying to figure out a way to fix this)
    private String PROFILE_PREFS = "ProfilePrefs";

    private String USER_ID_KEY = "UserIDKey";
    private String FIRST_NAME_KEY = "FirstNameKey";
    private String LAST_NAME_KEY = "LastNameKey";
    private String NICKNAME_KEY = "NicknameKey";
    private String EMAIL_KEY = "EmailKey";
    private String PHONE_KEY = "PhoneKey";

    // Member Variables
    private Button mSaveChangesBtn;
    private Button mHomepageBtn;
    private EditText mNicknameET;
    private EditText mEmailET;
    private EditText mPhoneET;

    private FirebaseAuth mAuth;
    private DatabaseReference mDatabaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        // Assigning values to member variables

        mSaveChangesBtn = findViewById(R.id.profileSaveChanges_Btn);
        mHomepageBtn = findViewById(R.id.profileHomepage_Btn);
        mNicknameET = findViewById(R.id.profileNickname_ET);
        mEmailET = findViewById(R.id.profileEmail_ET);
        mPhoneET = findViewById(R.id.profilePhone_ET);

        mAuth = FirebaseAuth.getInstance();
        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("users").child(mAuth.getUid());

        // Update edit text fields with user info from shared prefs
        updateUI();

        // On click listeners

        mSaveChangesBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveChanges();
            }
        });

        mHomepageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openHomepageActivity();
            }
        });
    }

    // fills profile UI with user info from shared prefs (not including profile picture)
    private void updateUI(){
        SharedPreferences prefs = getSharedPreferences(PROFILE_PREFS,0);

        mNicknameET.setText(prefs.getString(NICKNAME_KEY,""));
        mEmailET.setText(prefs.getString(EMAIL_KEY,""));
        mPhoneET.setText(prefs.getString(PHONE_KEY,""));
    }

    // will save changes to the nickname, email, and phone of user and update database accordingly
    private void saveChanges(){

    }

    // opens homepage activity
    private void openHomepageActivity(){
        Intent intent = new Intent(ProfileActivity.this, HomepageActivity.class);
        finish();
        startActivity(intent);
    }
}
