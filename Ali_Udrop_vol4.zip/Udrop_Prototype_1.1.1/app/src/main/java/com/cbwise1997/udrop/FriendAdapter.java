package com.cbwise1997.udrop;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

// adapter for the friend items for friends recycler view

public class FriendAdapter extends RecyclerView.Adapter<FriendAdapter.ViewHolder> {

    private static final String TAG = "FriendAdapter";

    private ArrayList<UserInfo> mFriendsList;
    private OnItemClickListener mListener;

    public interface OnItemClickListener{
        void onItemClick(View v ,int position);
        void onDeleteClick(View v, int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener){
        mListener = listener;
    }

    public FriendAdapter(ArrayList<UserInfo> friendsList) {
        mFriendsList = friendsList;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public ImageView mProfImage;
        public TextView mName;
        public ImageView mDeleteImage;

        public ViewHolder(View itemView, final OnItemClickListener listener) {
            super(itemView);
            mProfImage = itemView.findViewById(R.id.layoutFriendItem_profile_IV);
            mName = itemView.findViewById(R.id.layoutFriendItem_name_TV);
            mDeleteImage = itemView.findViewById(R.id.layoutFriendItem_options_IV);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if(position != RecyclerView.NO_POSITION){
                        listener.onItemClick(v ,position);
                    }
                }
            });

            mDeleteImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if(position != RecyclerView.NO_POSITION){
                        listener.onDeleteClick(v, position);
                    }
                }
            });
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.friend_item,parent,false);
        return new ViewHolder(view, mListener);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        Log.d(TAG,"onBindViewHolder: called.");
        UserInfo currentItem = mFriendsList.get(position);
        holder.mName.setText(currentItem.getFirstName() + " " + currentItem.getLastName());
    }

    @Override
    public int getItemCount() {
        return mFriendsList.size();
    }
 }