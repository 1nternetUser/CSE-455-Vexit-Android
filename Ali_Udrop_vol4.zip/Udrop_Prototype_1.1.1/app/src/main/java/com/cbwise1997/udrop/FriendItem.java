package com.cbwise1997.udrop;

public class FriendItem {
    private int mProfPic;
    private int mOptionsPic;
    private String mName;

    public FriendItem(int profPic,int optionsPic,String name){
        mProfPic = profPic;
        mOptionsPic = optionsPic;
        mName = name;
    }

    public String getName(){
        return mName;
    }

    public int getProfPic(){
        return mProfPic;
    }

    public int getOptionsPic(){
        return mOptionsPic;
    }

    public void setName(String name){
        mName = name;
    }

    public void setProfPic(int profPic){
        mProfPic = profPic;
    }

    public void setOptionsPic(int optionsPic){
        mOptionsPic = optionsPic;
    }
}