package com.cbwise1997.udrop;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class FriendsActivity extends AppCompatActivity {

    // Constants
    // IF ONE CONSTANT IS CHANGED IT MUST BE CHANGED IN EACH JAVA CLASS (trying to figure out a way to fix this)
    private String PROFILE_PREFS = "ProfilePrefs";

    private String USER_ID_KEY = "UserIDKey";
    private String FIRST_NAME_KEY = "FirstNameKey";
    private String LAST_NAME_KEY = "LastNameKey";
    private String NICKNAME_KEY = "NicknameKey";
    private String EMAIL_KEY = "EmailKey";
    private String PHONE_KEY = "PhoneKey";

    // Member Variables
    private Button mAddFriendBtn;
    private Button mHomepageBtn;
    private EditText mFriendEmailET;

    private SharedPreferences mProfPrefs;

    private DatabaseReference mUserRef;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friends);

        // Assigning member variables

        mAddFriendBtn = findViewById(R.id.friendsAddFriend_Btn);
        mHomepageBtn = findViewById(R.id.friendsHomepage_Btn);
        mFriendEmailET = findViewById(R.id.friendsEmail_ET);

        mProfPrefs = getSharedPreferences(PROFILE_PREFS,0);

        mUserRef = FirebaseDatabase.getInstance().getReference("users");

        // On click listeners

        mAddFriendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendFriendRequest();
            }
        });

        mHomepageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openHomepageActivity();
            }
        });
    }

    // attempts to send friend request to email address input by user
    private void sendFriendRequest() {
        final String email = mFriendEmailET.getText().toString().trim();
        // checking that email contains '@' sign
        if(!email.isEmpty() && email.contains("@")){
            mUserRef.addChildEventListener(new ChildEventListener() {
                @Override
                public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                    // if email in database matches email input by user then send friend request
                    if(dataSnapshot.child("userInfo/email").getValue().toString().equals(email)){
                        Log.d("Udrop","Sending request to: " + email);
                        toaster("Sending request to \n" + email);


                        // friend request from user is added to receiver's friendRequests on database
                        mUserRef
                                .child(dataSnapshot.child("userInfo/userID").getValue().toString())
                                .child("friendRequests")
                                .child(mProfPrefs.getString(USER_ID_KEY,""))
                                .setValue(mProfPrefs.getString(USER_ID_KEY,""));
                    }
                }

                @Override
                public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                }

                @Override
                public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

                }

                @Override
                public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }
    }

    // had to use this in the addFriend function to make a Toast message becaue it wouldn't
    // otherwise. kinda weird
    private void toaster(String message){
        Toast.makeText(this,message, Toast.LENGTH_SHORT).show();
    }

    // opens homepage activity
    private void openHomepageActivity() {
        Intent intent = new Intent(FriendsActivity.this, HomepageActivity.class);
        finish();
        startActivity(intent);
    }
}