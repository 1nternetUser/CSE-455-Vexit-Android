package com.cbwise1997.udrop;

import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Debug;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.model.PlaceLikelihood;
import com.google.android.libraries.places.api.net.FindCurrentPlaceRequest;
import com.google.android.libraries.places.api.net.FindCurrentPlaceResponse;
import com.google.android.libraries.places.api.net.PlacesClient;
import com.google.firebase.auth.FirebaseAuth;

import java.util.Collections;
import java.util.List;

public class LocationsActivity extends FragmentActivity implements OnMapReadyCallback {

    private static final int PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION = 99;
    private static final String TAG = MapsActivityCurrentPlace.class.getSimpleName();
    private static final Object NETWORK_PROVIDER = "network";
    private EditText mMessage;
    private Button mHomepageBtn ,mNextBtn;
    private GoogleMap mMap;
    boolean mLocationPermissionGranted;
    private FirebaseAuth mAuth;
    private Location mLastKnownLocation;
    private LocationRequest locationRequest;
    public LatLng mDefaultLocatio;
    private LatLng California = new LatLng(36, 119);
    protected static final int REQUEST_CHECK_SETTINGS = 0x1;
    // CHANGES ZOOOOOOM
    private final float DEFAULT_ZOOM = 15;
    private FusedLocationProviderClient mFusedProviderClient;
    private LocationCallback mLocationCallback;
    private LocationManager locationManager;


    public class MapsActivityCurrentPlace extends AppCompatActivity {
        private GoogleMap mMap;
        private CameraPosition mCameraPosition;
        private PlacesClient mPlacesClient;
        private static final int DEFAULT_ZOOM = 15;
        private static final int PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION = 1;
        private boolean mLocationPermissionGranted;
        private Location mLastKnownLocation;
        private static final String KEY_CAMERA_POSITION = "camera_position";
        private static final String KEY_LOCATION = "location";
        private static final int M_MAX_ENTRIES = 5;
        private String[] mLikelyPlaceNames;
        private String[] mLikelyPlaceAddresses;
        private List[] mLikelyPlaceAttributions;
        private LatLng[] mLikelyPlaceLatLngs;
        private Button mHomepageBtn, mSendBtn;
        private Button mAddLocationBtn;
        List<Place.Field> placeFields = Collections.singletonList(Place.Field.NAME);
        FindCurrentPlaceRequest request =
                FindCurrentPlaceRequest.newInstance(placeFields);
        public void onMapReady(GoogleMap googleMap) {

        }


        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_locations);
            final Bundle mEmail = getIntent().getExtras();
            if (mEmail != null) {
                String emailToMessage = mEmail.getString("mEmail");
                //The key argument here must match that used in the other activity
                toaster(emailToMessage + " Test");
            }

            mHomepageBtn = findViewById(R.id.mBack);
            mSendBtn = findViewById(R.id.mSend);
            mSendBtn.setOnClickListener(new View.OnClickListener() {
                Bundle mEmail = null;
                String emailToMessage = null;
                @Override
                public void onClick(View v) {

                    //SEND THE MESSAGE HERE
                    openHomepageActivity();
                }

            });
            // On click listeners
            mHomepageBtn.setOnClickListener(new View.OnClickListener() {
                Bundle mEmail = null;
                String emailToMessage = null;
                @Override
                public void onClick(View v) {
                    openHomepageActivity();
                }
            });
            mFusedProviderClient = LocationServices.getFusedLocationProviderClient(this);
            // Location_Client.connect();
            mLocationCallback = new LocationCallback() {
                @Override
                public void onLocationResult(LocationResult locationResult) {
                    super.onLocationResult(locationResult);
                }
            };
            createLocationRequest();
            LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder()
                    .addLocationRequest(locationRequest);
            SettingsClient client = LocationServices.getSettingsClient(this);
            Task<LocationSettingsResponse> task = client.checkLocationSettings(builder.build());
            task.addOnSuccessListener(this, new OnSuccessListener<LocationSettingsResponse>() {
                @Override
                public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
                    // All location settings are satisfied. The client can initialize
                    // location requests here.
                    // ...
                }
            });

            task.addOnFailureListener(this, new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    if (e instanceof ResolvableApiException) {
                        // Location settings are not satisfied, but this can be fixed
                        // by showing the user a dialog.
                        try {
                            // Show the dialog by calling startResolutionForResult(),
                            // and check the result in onActivityResult().
                            ResolvableApiException resolvable = (ResolvableApiException) e;
                            resolvable.startResolutionForResult(LocationsActivity.this,
                                    REQUEST_CHECK_SETTINGS);
                        } catch (IntentSender.SendIntentException sendEx) {
                            // Ignore the error.
                        }
                    }
                }
            });


            SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                    .findFragmentById(R.id.map);
        }



        private void openHomepageActivity(){
            Intent intent = new Intent(LocationsActivity.this,HomepageActivity.class);
            finish();
            startActivity(intent);
        }
        private void toaster(String emailToMessage) {
            Toast.makeText(this, emailToMessage, Toast.LENGTH_SHORT).show();
        }
    }
    private void startLocationUpdates() {
        Log.d(TAG, "ali made it to start location" );
        mFusedProviderClient.requestLocationUpdates(locationRequest,
                mLocationCallback,
                Looper.getMainLooper());
        Toast.makeText(getApplicationContext(),"Ali :MLocationCallback"+ mLocationCallback,Toast.LENGTH_SHORT).show();
    }
    protected void createLocationRequest() {
//        Toast.makeText(getApplicationContext(),"Ali made ONE locaiton Request",Toast.LENGTH_SHORT).show();
        LocationRequest locationRequest = LocationRequest.create();
        locationRequest.setInterval(10000);
        locationRequest.setFastestInterval(5000);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
    }

    private void getDeviceLocation() {// ERROR BELOW BC IT HAS NOT BEEN CALLED YET
//        Toast.makeText(getApplicationContext(),mLastKnownLocation.getLongitude() +" : " + mLastKnownLocation.getLatitude(),Toast.LENGTH_SHORT).show();

        /*
         * Get the best and most recent location of the device, which may be null in rare
         * cases when a location is not available.
         */
        try {
            if (mLocationPermissionGranted) {
                Task<Location> locationResult = mFusedProviderClient.getLastLocation();                   // TTY THIS IF NO WORKKrequestLocationUpdates();
                //requestLocationUpdates(locationRequest.create(),mLocationCallback, Looper.getMainLooper()  ); //.requestLocationUpdates();
//                Toast.makeText(getApplicationContext(),mLastKnownLocation.getLongitude() +" : " + mLastKnownLocation.getLatitude(),Toast.LENGTH_SHORT).show();

                // Toast.makeText(getApplicationContext(),mFusedProviderClient.getLastLocation()+" : ",Toast.LENGTH_SHORT).show();

                locationResult.addOnCompleteListener(this, new OnCompleteListener() {
                    @Override
                    public void onComplete(@NonNull Task task) {
                        if (task.isSuccessful()) {

                            // Set the map's camera position to the current location of the device.
                            //    Toast.makeText(getApplicationContext(),task.getResult()+" : ",Toast.LENGTH_SHORT).show();

                            startLocationUpdates();
                            createLocationRequest();
                            mLastKnownLocation = (Location) task.getResult();
                            // mLastKnownLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                            assert mLastKnownLocation != null;
                            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(
                                    new LatLng(mLastKnownLocation.getLongitude(), mLastKnownLocation.getLatitude()), DEFAULT_ZOOM));
                            Toast.makeText(getApplicationContext(),mLastKnownLocation.getLongitude() +" : " + mLastKnownLocation.getLatitude(),Toast.LENGTH_SHORT).show();
                        } else {
                            Log.d(TAG, "Current location is null. Using defaults.");
                            Log.e(TAG, "Exception: %s", task.getException());
                            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(California, DEFAULT_ZOOM));
                            mMap.getUiSettings().setMyLocationButtonEnabled(false);
                        }
                    }
                });
            }
        } catch(SecurityException e)  {
            Log.e("Exception: %s", e.getMessage());
        }
    }
    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */

    private void getLocationPermission() {
        /*
         * Request location permission, so that we can get the location of the
         * device. The result of the permission request is handled by a callback,
         * onRequestPermissionsResult.
         */
        if (ContextCompat.checkSelfPermission(this.getApplicationContext(),
                android.Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            mLocationPermissionGranted = true;
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
                    PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION);
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        Log.d(TAG,"ali mde it to reequest permissions result");

        mLocationPermissionGranted = false;
        switch (requestCode) {
            case PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    mLocationPermissionGranted = true;
                }
            }
        }
        updateLocationUI();
    }

    private void updateLocationUI( ) {
        if (mMap == null) {
            return;
        }
        try {
            if (mLocationPermissionGranted) {
                mMap.setMyLocationEnabled(true);
                mMap.getUiSettings().setMyLocationButtonEnabled(true);
                Log.d(TAG,"ali mde it to updatelocation granted");

            } else {
                Log.d(TAG,"ali mde it to updatelocation denied");

                mMap.setMyLocationEnabled(false);
                mMap.getUiSettings().setMyLocationButtonEnabled(false);
                Object mLastKnownLocation = null;
                getLocationPermission();
            }
        } catch (SecurityException e)  {
            Log.e("Exception: %s", e.getMessage());
        }
    }
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        getLocationPermission();
        updateLocationUI();
        getDeviceLocation();
        LatLng sydney = new LatLng(-34, 151);
        mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            //mMap.updateLocationUI();

            @Override
            public void onMapClick(LatLng position) {
                mMap.clear();
                mMap.addMarker(new MarkerOptions().position(position));
                double longitude = position.longitude;
                double latitude = +position.latitude;
                Toast.makeText(getApplicationContext(),longitude +" : "+ latitude,Toast.LENGTH_SHORT).show();

            }
        });
    }

    private void openHomepageActivity() {
        Intent intent = new Intent(LocationsActivity.this, HomepageActivity.class);
        finish();
        startActivity(intent);
    }
}