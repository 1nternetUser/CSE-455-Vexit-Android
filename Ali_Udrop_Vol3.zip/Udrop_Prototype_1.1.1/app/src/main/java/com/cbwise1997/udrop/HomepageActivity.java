package com.cbwise1997.udrop;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.util.Strings;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;


public class HomepageActivity extends AppCompatActivity {

    // Constants
    // IF ONE CONSTANT IS CHANGED IT MUST BE CHANGED IN EACH JAVA CLASS (trying to figure out a way to fix this)
    private String PROFILE_PREFS = "ProfilePrefs";
    private String TAG = "HOMEPAGE1";

    private String USER_ID_KEY = "UserIDKey";
    private String FIRST_NAME_KEY = "FirstNameKey";
    private String LAST_NAME_KEY = "LastNameKey";
    private String NICKNAME_KEY = "NicknameKey";
    private String EMAIL_KEY = "EmailKey";
    private String PHONE_KEY = "PhoneKey";

    // Member Variables

    private Button mLoginActivityBtn;
    private Button mDropsBtn;
    private Button mFriendsBtn;
    private Button mProfileBtn;
    private Button mLocationsBtn;
    private TextView mViewTitleTV;

    private ImageButton mAddFriendImgBtn;
    private EditText mAddFriendET;
    private ArrayList<UserInfo> mFriends = new ArrayList<>();
    private RecyclerView mFriendsRV;
    private FriendAdapter mFriendAdapter;
    private RecyclerView.LayoutManager mFriendLayoutManager;

    private ArrayList<UserInfo> mFriendRequests;
    private RecyclerView mFriendRequestsRV;
    private FriendRequestAdapter mFriendRequestAdapter;
    private RecyclerView.LayoutManager mFriendRequestLayoutManager;

    private ArrayList<String> mMenuItems;
    private RecyclerView mMenuRV;

    private FirebaseAuth mAuth;
    private DatabaseReference mRef;
    private DatabaseReference mFriendsRef;

    private SharedPreferences mUserPrefs;
    private UserInfo mUserInfo;
    private String mUID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);

        // Assign member variable values
        mViewTitleTV = findViewById(R.id.homepageViewTitle_TV);
        mAddFriendImgBtn = findViewById(R.id.homepageAddFriend_ImgBtn);
        mAddFriendET = findViewById(R.id.homepageAddFriend_ET);


        mFriendRequests = new ArrayList<>();
        mFriends = new ArrayList<>();
        mFriendRequestAdapter = new FriendRequestAdapter(mFriendRequests);
        mFriendAdapter = new FriendAdapter(mFriends);

        mAuth = FirebaseAuth.getInstance();


        mUserPrefs = getSharedPreferences(PROFILE_PREFS, 0);
        mRef = FirebaseDatabase.getInstance().getReference("users");
        mFriendsRef = FirebaseDatabase.getInstance().getReference("users/" + mUID + "/friendsList");
        mUID = mAuth.getUid();
        getUserInfo();
        // On click listeners

        mAddFriendImgBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toaster("Sent friend request to\n" + mAddFriendET.getText());
                sendFriendRequest();
            }
        });

        // Database listeners
        setFriendRequestDatabaseListener();
        setFriendsDatabaseListener();

        // function calls

        buildMenu();
    }
// onCreate functions ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    // gets current user info from database
    public void getUserInfo() {
        mRef.child(mUID + "/userInfo").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                mUserInfo = dataSnapshot.getValue(UserInfo.class);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
// MENU FUNCTIONS ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    // builds menu recycler view
    public void buildMenu() {
        mMenuItems = new ArrayList<>();
        mMenuItems.add("Drops");
        mMenuItems.add("Friends");
        mMenuItems.add("Saved Locations");
        mMenuItems.add("Profile");
        mMenuItems.add("Logout");

        mMenuRV = findViewById(R.id.homepageMenu_RV);
        RecyclerView.LayoutManager menuLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        MenuRecyclerViewAdapter menuAdapter = new MenuRecyclerViewAdapter(mMenuItems);
        mMenuRV.setLayoutManager(menuLayoutManager);
        mMenuRV.setAdapter(menuAdapter);
        menuAdapter.setOnItemClickListener(new MenuRecyclerViewAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                doMenuAction(position);
            }
        });
    }

    // performs action of menu item clicked
    public void doMenuAction(int position) {
        mMenuRV.setEnabled(false);
        String label = mMenuItems.get(position);
        Toast.makeText(this, label, Toast.LENGTH_SHORT).show();
        createScreenSpace(label);
        if (label.equals("Drops")) {
            openDropsActivity();
        } else if (label.equals("Friends")) {
            //setFriendsDatabaseListener();
            buildFriendRequestsRecyclerView();
            buildFriendsRecyclerView();
        } /*else if (label.equals("Saved Locations")) {
            mMenuRV.setEnabled(true);
            openLocationsActivity();
        }*/ else if (label.equals("Profile")) {
            mMenuRV.setEnabled(true);
            openProfileActivity();
        } else if (label.equals("Logout")) {
            mMenuRV.setEnabled(true);
            openLoginActivity();
        }
        mMenuRV.setEnabled(true);
    }

    // creates space on screen by clearing current views and showing new views
    public void createScreenSpace(String label) {
        if (label.equals("Drops")) {
        } else if (label.equals("Friends")) {
            mViewTitleTV.setText(label);
            //mViewTitleTV.setVisibility(View.VISIBLE);
            //mAddFriendImgBtn.setVisibility(View.VISIBLE);
            //mAddFriendET.setVisibility(View.VISIBLE);
            //mFriendRequestsRV.setVisibility(View.VISIBLE);
            //mFriendsRV.setVisibility(View.VISIBLE);
        } else if (label.equals("Saved Locations")) {
        } else if (label.equals("Profile")) {
        }
    }


// FRIENDS LIST FUNCTIONS ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    // listener for friends list updates in database
    public void setFriendsDatabaseListener() {
        Log.d(TAG, "setFriendsDatabaseListener(): called");

        mRef.child(mUID + "/friendsList").addValueEventListener(new ValueEventListener() {
            // executed when friendsList is changed on database
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Log.d(TAG, "onDataChange: friends list changed");
                mFriends = new ArrayList<>();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    mFriends.add(snapshot.getValue(UserInfo.class));
                    Log.d(TAG, "Friend email: " + snapshot.child("email").getValue());
                }
                mFriendAdapter.notifyDataSetChanged();
                buildFriendsRecyclerView();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    // get friend requests from database
    public void setFriendRequestDatabaseListener() {
        Log.d(TAG, "setFriendRequestDatabaseListener(): called");

        // getting request information from database
        mRef.child(mUID + "/friendRequests").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Log.d(TAG, "onDataChange: friend requests list changed");
                mFriendRequests = new ArrayList<>();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Log.d(TAG, "Sender email: " + snapshot.child("email").getValue());
                    mFriendRequests.add(snapshot.getValue(UserInfo.class));
                }
                mFriendRequestAdapter.notifyDataSetChanged();
                buildFriendRequestsRecyclerView();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    // create a new friend request from sender in receivers friend requests on database
    public void sendFriendRequest() {
        mAddFriendImgBtn.setEnabled(false);
        final String receiverEmail = mAddFriendET.getText().toString().trim();
        mAddFriendET.setText("");

        mRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    if (snapshot.child("userInfo/email").getValue().toString().equals(receiverEmail)) {
                        // adding user to receiver friends list on database
                        mRef.child(snapshot.getKey().toString() + "/friendRequests/" + mUID).setValue(mUserInfo);

                        return;
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        mAddFriendImgBtn.setEnabled(true);
    }

    // not currently used in app (used only for testing)
    // adds friend to friends list without the need for sending or accepting friend request
    public void addFriend(final String email) {
        mAddFriendImgBtn.setEnabled(false);
        mRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    if (snapshot.child("userInfo/email").getValue().equals(email)) {
                        Log.d(TAG, "Add Friend: " + snapshot.getValue());
                        UserInfo friendInfo = snapshot.child("userInfo").getValue(UserInfo.class);
                        Log.d(TAG, "FriendUID: " + friendInfo.getUserID());
                        // adding friend to user friendList in firebase
                        mRef.child(mUID + "/friendsList/" + friendInfo.getUserID())
                                .setValue(friendInfo);

                        // adding user to friend friendList in firebase
                        mRef.child(friendInfo.getUserID() + "/friendsList/" + mUID)
                                .setValue(mUserInfo);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        mAddFriendImgBtn.setEnabled(true);
    }


    // removes friend from recycler view and from database
    public void removeFriend(int position) {
        String friendID = mFriends.get(position).getUserID();
        mRef.child(mUID + "/friendsList/" + friendID).removeValue();
        mRef.child(friendID + "/friendsList/" + mUID).removeValue();

        //leave below lines commented for now, causes weird animation and potential app crash
        //mFriends.remove(position);
        //mFriendAdapter.notifyItemRemoved(position);
    }

    // removes friend request from recycler view and from database
    public void declineFriendRequest(int position) {
        Log.d(TAG, "position: " + position);
        Log.d(TAG, "size: " + mFriendRequests.size());

        String friendID = mFriendRequests.get(position).getUserID();
        mRef.child(mUID + "/friendRequests/" + friendID).removeValue();
    }

    // adds sender to receiver friend list, adds receiver to sender friend list, and removes sender from receiver friend request
    public void acceptFriendRequest(int position) {
        String friendID = mFriendRequests.get(position).getUserID();

        mRef.child(mUID + "/friendsList/" + friendID).setValue(mFriendRequests.get(position));
        mRef.child(friendID + "/friendsList/" + mUID).setValue(mUserInfo);

        mRef.child(mUID + "/friendRequests/" + friendID).removeValue();
        mRef.child(friendID + "/friendRequests/" + mUID).removeValue();
    }

    // fills friends recycler view with items from friends list
    public void buildFriendsRecyclerView() {
        mFriendsRV = findViewById(R.id.homepageFriends_RV);
        mFriendLayoutManager = new LinearLayoutManager(this);
        mFriendAdapter = new FriendAdapter(mFriends);
        mFriendsRV.setLayoutManager(mFriendLayoutManager);
        mFriendsRV.setAdapter(mFriendAdapter);
        mFriendAdapter.setOnItemClickListener(new FriendAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                String emailToMessage = mFriends.get(position).getEmail();
//                toaster(mFriends.get(position).getFirstName() + ' ' + mFriends.get(position).getEmail());
                openLocationsActivity(emailToMessage);
            }

            @Override
            public void onDeleteClick(View view, int position) {
                removeFriend(position);
            }
        });
    }

    // fills friend requests recycler view with items from friend requests list
    public void buildFriendRequestsRecyclerView() {
        mFriendRequestsRV = findViewById(R.id.homepageFriendRequests_RV);
        mFriendRequestLayoutManager = new LinearLayoutManager(this);
        mFriendRequestAdapter = new FriendRequestAdapter(mFriendRequests);
        mFriendRequestsRV.setLayoutManager(mFriendRequestLayoutManager);
        mFriendRequestsRV.setAdapter(mFriendRequestAdapter);
        mFriendRequestAdapter.setOnItemClickListener(new FriendRequestAdapter.OnItemClickListener() {
            @Override
            public void onAcceptClick(View view, int position) {
                acceptFriendRequest(position);
                buildFriendsRecyclerView();
                toaster("Accepted: " + mFriendRequests.get(position).getFirstName());
            }

            @Override
            public void onDeclineClick(View view, int position) {
                declineFriendRequest(position);
                toaster("Declined: " + mFriendRequests.get(position).getFirstName());
            }
        });
    }

    // had to use this in the many functions to make a Toast message because it wouldn't
    // otherwise. kinda weird
    private void toaster(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

// open new activity functions //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    private void openProfileActivity() {
        Intent profileActivity = new Intent(this, ProfileActivity.class);
        finish();
        startActivity(profileActivity);
    }

    private void openFriendsActivity() {
        Intent friendsActivity = new Intent(this, FriendsActivity.class);
        finish();
        startActivity(friendsActivity);
    }

    private void openDropsActivity() {
        Intent dropsActivity = new Intent(this, DropsActivity.class);
        finish();
        startActivity(dropsActivity);
    }

    private void openLocationsActivity(String emailToMessage) {
        toaster("going to next" );
        Intent locationsActivity = new Intent(this, LocationsActivity.class);
        locationsActivity.putExtra("mEmail", emailToMessage);
        finish();
        startActivity(locationsActivity);
    }

    private void openLoginActivity() {
        Intent dropsActivity = new Intent(this, LoginActivity.class);
        finish();
        startActivity(dropsActivity);
    }
}