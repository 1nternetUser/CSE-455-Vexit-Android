package com.cbwise1997.udrop;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

// adapter for the friend request items for friend requests recycler view
public class FriendRequestAdapter extends RecyclerView.Adapter<FriendRequestAdapter.ViewHolder> {
    private static final String TAG = "FriendReqAdapter";

    private ArrayList<UserInfo> mFriendRequests;
    private OnItemClickListener mListener;

    public interface OnItemClickListener{
        void onAcceptClick(View view, int position);
        void onDeclineClick(View view, int position);
    }

    public void setOnItemClickListener(FriendRequestAdapter.OnItemClickListener listener){
        mListener = listener;
    }

    public FriendRequestAdapter(ArrayList<UserInfo> friendRequests) {
        mFriendRequests = friendRequests;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{

        public ImageView mProfImage;
        public ImageView mAcceptImage;
        public ImageView mDeclineImage;
        public TextView mName;

        public ViewHolder(View itemView, final OnItemClickListener listener) {
            super(itemView);
            mProfImage = itemView.findViewById(R.id.friend_request_image);
            mAcceptImage = itemView.findViewById(R.id.friend_request_accept);
            mDeclineImage = itemView.findViewById(R.id.friend_request_decline);
            mName = itemView.findViewById(R.id.friend_request_name);

            mAcceptImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if(position != RecyclerView.NO_POSITION){
                        Log.d(TAG, "onAcceptClick at position " + position);
                        listener.onAcceptClick(v, position);
                    }
                }
            });

            mDeclineImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if(position != RecyclerView.NO_POSITION){
                        Log.d(TAG, "onDeclineClick at position " + position);
                        listener.onDeclineClick(v, position);
                    }
                }
            });
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Log.d(TAG, "onCreateViewHolder: called");
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.friend_request_item,parent,false);
        return new ViewHolder(view, mListener);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Log.d(TAG,"onBindViewHolder: called at position " + position);
        UserInfo currentItem = mFriendRequests.get(position);
        holder.mName.setText(currentItem.getFirstName() + " " + currentItem.getLastName());
    }

    @Override
    public int getItemCount() {
        Log.d(TAG, "getItemCount: " + mFriendRequests.size());
        return mFriendRequests.size();
    }
}
