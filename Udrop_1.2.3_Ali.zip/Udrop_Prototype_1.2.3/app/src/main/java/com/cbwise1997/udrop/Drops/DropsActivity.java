package com.cbwise1997.udrop.Drops;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.IntentSender;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.cbwise1997.udrop.Friends.FriendListAdapter;
import com.cbwise1997.udrop.Friends.FriendsActivity;
import com.cbwise1997.udrop.Locations.LocationsActivity;
import com.cbwise1997.udrop.MenuRecyclerViewAdapter;
import com.cbwise1997.udrop.Messages.MapsMessengerActivity;
import com.cbwise1997.udrop.Messages.Messages;
import com.cbwise1997.udrop.ProfileActivity;
import com.cbwise1997.udrop.R;
import com.cbwise1997.udrop.UserInfo;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class DropsActivity extends FragmentActivity implements OnMapReadyCallback {

    private static final String FINE_LOCATION = Manifest.permission.ACCESS_FINE_LOCATION;
    private static final String COARSE_LOCATION = Manifest.permission.ACCESS_COARSE_LOCATION;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1234;
    private static final float DEFAULT_ZOOM = 16f;

    //widgets
    private ImageView mMyLocationImgVw;
    private ImageView mSaveLocationImgVw;
    private ImageView mCancelImgVw;
    private ImageView mSendImgVw;
    private EditText mNewLocationET;

    //vars
    private Boolean mLocationPermissionGranted = false;
    private GoogleMap mMap;
    private FusedLocationProviderClient mFLPC;
    private MarkerOptions mPinDrop;
    private static double Latitude = 1, Longitude = 1;
    private static double lat2, long2;
    private static LatLng latlng1, latlng2;

    private FirebaseAuth mAuth;
    private DatabaseReference mRef;

    private Bundle mExtras;
    private SharedPreferences mUserPrefs;
    private UserInfo mUserInfo;
    private String mUID;
    private static final String TAG = "DropsActivity";

    private static final double STANDARD_RADIUS = 1.015; // radius is in kilometers, so 0.015 = 15 meter radius
    private static final int MAX_UPDATE_INTERVAL = 3000;
    private static final int MIN_UPDATE_INTERVAL = 2000;
    //selecter variables
    private static boolean isSelected = false;
    private static ArrayList<View> ViewArrays = new ArrayList<View>(1);
    //widgets
    private RecyclerView mDropsRV;
    private RecyclerView mMenuRV;
    private TextView mDropsTitleTV;

    // variables
    private ArrayList<Messages> mDrops;
    private ArrayList<String> mMenuItems;
    private DropsAdapter mDropsAdapter;
    private RecyclerView.LayoutManager mDropsLayoutManager;


    private LocationRequest mLocationRequest;

    private LocationCallback mLocationCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drops);
        mMyLocationImgVw = (ImageView) findViewById(R.id.maps_messenger_my_location_imgvw);
        mSaveLocationImgVw = (ImageView) findViewById(R.id.maps_messenger_save_location_imgvw);
        mCancelImgVw = (ImageView) findViewById(R.id.maps_messenger_cancel_imgvw);
        mSendImgVw = (ImageView) findViewById(R.id.maps_messenger_send_imgvw);
        mNewLocationET = (EditText) findViewById(R.id.maps_messenger_new_location_edttxt) ;


        mAuth = FirebaseAuth.getInstance();
        mRef = FirebaseDatabase.getInstance().getReference("users");
        mUID = mAuth.getUid();
        mExtras = getIntent().getExtras();

        getLocationPermission();
        init();
    }

    // initializes google map and calls init()
    @Override
    public void onMapReady(GoogleMap googleMap) {
        Toast.makeText(this,"Map is ready",Toast.LENGTH_SHORT).show();
        mMap = googleMap;
        mMap.setMyLocationEnabled(true);
        mMap.getUiSettings().setMyLocationButtonEnabled(false);
        mMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);

        // if permission granted then set camera to device location and drop pin
        if(mLocationPermissionGranted){
            getDeviceLocation();
            init();
        }
        // map click listener that drops pin where user clicks


    }
    // checking for permissions granted
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        Log.d(TAG, "onRequestPermissionsResult: called");
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        mLocationPermissionGranted = false;
        switch(requestCode){
            case LOCATION_PERMISSION_REQUEST_CODE:{
                if(grantResults.length > 0){
                    for(int i = 0; i < grantResults.length; ++i){
                        // permission was not granted
                        if(grantResults[i] != PackageManager.PERMISSION_GRANTED){
                            Log.d(TAG, "onRequestPermissionsResult: permission failed");
                            return;
                        }

                        // permission granted so initialize map
                        mLocationPermissionGranted = true;
                        initMap();
                    }
                }
            }
        }
    }

    private void init(){
        mMenuRV = (RecyclerView) findViewById(R.id.drops_menu_recvw);
        mDropsRV = (RecyclerView) findViewById(R.id.drops_drops_recvw);
        mDropsTitleTV = (TextView) findViewById(R.id.drops_title_txtvw);

        mRef = FirebaseDatabase.getInstance().getReference("users");
        mAuth = FirebaseAuth.getInstance();
        mUID = mAuth.getUid();
        mDrops = new ArrayList<>();
        mMenuItems = new ArrayList<>();

        mLocationCallback = new LocationCallback(){
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if(locationResult == null) {
                    return;
                }
                for(final Location location : locationResult.getLocations()){
                    Log.d(TAG, "onLocationResult: " + location.toString());
                    mRef.child(mUID + "/drops").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            latlng2 = new LatLng(location.getLatitude(),location.getLongitude());
                            /*
                            for(DataSnapshot snapshot : dataSnapshot.getChildren()){
                                if(Integer.parseInt(snapshot.child("status").getValue().toString()) == 1){
                                    lat2 = Double.parseDouble(snapshot.child("latitude").getValue().toString());
                                    long2 = Double.parseDouble(snapshot.child("longitude").getValue().toString());;
                                    latlng2 = new LatLng(lat2,long2);
                                    if(distance(latLng,latlng2) <= STANDARD_RADIUS){
                                        DatabaseReference ref = snapshot.child("status").getRef();
                                        ref.setValue(0);
                                    }
                                }
                            }
                            */
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });
                }
            }
        };

  //      mFLPC = LocationServices.getFusedLocationProviderClient(this);

        mLocationRequest = LocationRequest.create();
        mLocationRequest.setInterval(MAX_UPDATE_INTERVAL);
        mLocationRequest.setFastestInterval(MIN_UPDATE_INTERVAL);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

     //   getLocationPermission();

        checkSettings();

        setDropsDatabaseListener();

        buildMenu();

    }
    // initializes google map
    private void initMap(){
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.maps_drops_map_fragment);
        assert mapFragment != null;
        mapFragment.getMapAsync(this);
    }
    private void getDeviceLocation(){
        Log.d(TAG, "getDeviceLocation: getting current device location");

        mFLPC = LocationServices.getFusedLocationProviderClient(this);

        try{
            // checking for permission to access device location
            if(mLocationPermissionGranted){
                // getting location
                Task location = mFLPC.getLastLocation();
                location.addOnCompleteListener(new OnCompleteListener() {
                    @Override
                    public void onComplete(@NonNull Task task) {

                        // success
                        if(task.isSuccessful()){
                            Location currentLocation = (Location) task.getResult();

                            Log.d(TAG, "onComplete: lat: " + currentLocation.getLatitude() + " lng: " + currentLocation.getLongitude());
                            moveCamera( new LatLng(currentLocation.getLatitude(),currentLocation.getLongitude()), DEFAULT_ZOOM, "My Location");
                        }

                        // failure
                        else {
                            Log.d(TAG, "onComplete: unable to get current location");
                            Toast.makeText(DropsActivity.this, "Unable to get current location.", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        }
        catch(SecurityException e){
            Log.e(TAG, "getDeviceLocation: Security Exception: " + e.getMessage());
        }
    }


    // moves camera and drops pin at given LatLng
    public void moveCamera(LatLng latLng, float zoom, String title){
        Log.d(TAG, "moveCamera: moving to lat: " + latLng.latitude + "lng: " + latLng.longitude);
        mMap.clear();
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, zoom));
        if (!ViewArrays.isEmpty()){
        mMap.addCircle( new CircleOptions()
                .center(latLng)
                .radius(100)
                .strokeColor(Color.LTGRAY)
                .fillColor(Color.BLUE));
        }
        else {
            mMap.clear();
        }
    }


    // if permissions have not already been granted, a permissions dialog will appear
    private void getLocationPermission(){
        Log.d(TAG, "getLocationPermission: getting location permissions");
        String[] permissions = {Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION};
        if(ContextCompat.checkSelfPermission(this.getApplicationContext(), FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED){
            if(ContextCompat.checkSelfPermission(this.getApplicationContext(), COARSE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED){
                mLocationPermissionGranted = true;
                initMap();
            }
        }
        else {
            Log.d(TAG, "PERMISSION ERRORRR?!");
            // prompt user to allow permissions
            ActivityCompat.requestPermissions(this,permissions,LOCATION_PERMISSION_REQUEST_CODE);
        }
    }

    public void addCircleRadius(LatLng latLng){
        mMap.addCircle( new CircleOptions()
                .center(latLng)
                .radius(100)
                .strokeColor(Color.LTGRAY)
                .fillColor(Color.BLUE));
    }

    //calculates distance between two LatLng objects
    private double distance(LatLng latLng1, LatLng latLng2){
        double theta = latLng1.longitude - latLng2.longitude;
        double dist = Math.sin(degToRad(latLng1.latitude))
                * Math.sin(degToRad(latLng2.latitude))
                + Math.cos(degToRad(latLng1.latitude))
                * Math.cos(degToRad(latLng2.latitude))
                * Math.cos(degToRad(theta));
        dist = Math.acos(dist);
        dist = radToDeg(dist);
        dist = dist * 60 * 1.1515;
        return (dist);
    }

    private double degToRad(double deg) {
        return (deg * Math.PI / 180.0);
    }

    private double radToDeg(double rad) {
        return (rad * 180.0 / Math.PI);
    }

    // checks that phone has correct settings enabled to send location updates
    private void checkSettings(){
        LocationSettingsRequest request = new LocationSettingsRequest.Builder()
                .addLocationRequest(mLocationRequest)
                .build();

        SettingsClient client = LocationServices.getSettingsClient(this);

        Task<LocationSettingsResponse> locationSettingsResponseTask = client.checkLocationSettings(request);

        locationSettingsResponseTask.addOnSuccessListener(new OnSuccessListener<LocationSettingsResponse>() {
            @Override
            public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
                startLocationUpdates();
            }
        });

        locationSettingsResponseTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                // if error is resolvable then try to solve it
                if(e instanceof ResolvableApiException){
                    ResolvableApiException apiException = (ResolvableApiException) e;
                    try {
                        apiException.startResolutionForResult(DropsActivity.this, 1001);
                    } catch (IntentSender.SendIntentException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });
    }

    // begin sending device location updates
    private void startLocationUpdates(){
        mFLPC.requestLocationUpdates(mLocationRequest, mLocationCallback, Looper.getMainLooper());
    }

    // builds menu recycler view
    private void buildMenu() {
        mMenuItems = new ArrayList<>();
        mMenuItems.add("Drops");
        mMenuItems.add("Friends");
        mMenuItems.add("Places");
        mMenuItems.add("Profile");

        mMenuRV = findViewById(R.id.drops_menu_recvw);
        mDropsTitleTV.setText("Drops");
        RecyclerView.LayoutManager menuLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        MenuRecyclerViewAdapter menuAdapter = new MenuRecyclerViewAdapter(mMenuItems);
        mMenuRV.setLayoutManager(menuLayoutManager);
        mMenuRV.setAdapter(menuAdapter);
        menuAdapter.setOnItemClickListener(new MenuRecyclerViewAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                doMenuAction(position);
            }
        });
    }

    // performs action of menu item clicked
    private void doMenuAction(int position) {
        mMenuRV.setEnabled(false);

        String label = mMenuItems.get(position);
        Toast.makeText(this, label, Toast.LENGTH_SHORT).show();

        if (label.equals("Drops")) {
        } else if (label.equals("Friends")) {
            openFriendsActivity();
        } else if (label.equals("Places")) {
            openLocationsActivity();
        } else if (label.equals("Profile")) {
            openProfileActivity();
        }
        mMenuRV.setEnabled(true);
    }


    // fills friends recycler view with items from friends list
    private void buildDropsRecyclerView() {
        mDropsLayoutManager = new LinearLayoutManager(this);
        mDropsAdapter = new DropsAdapter(mDrops);
        mDropsRV.setLayoutManager(mDropsLayoutManager);
        mDropsRV.setAdapter(mDropsAdapter);
        mDropsAdapter.setOnItemClickListener(new DropsAdapter.OnItemClickListener() {
            // shows a toast message with name of friend
            @Override
            public void onItemClick(View view, int position) {
                if (!ViewArrays.isEmpty()) {
                    if (ViewArrays.get(0).equals(view)){  //You clicked on a selected item
                        view.setBackgroundColor(Color.WHITE);
                        ViewArrays.remove(0);
                        toaster("Latitude: " + Latitude + " & Longitude: "+ Longitude);
                        isSelected = false;
                        mMap.clear();
                    }
                    else {         // you selected another item
                        ViewArrays.get(0).setBackgroundColor(Color.WHITE);
                        ViewArrays.set(0, view);
                        view.setBackgroundColor(Color.RED);
                        Latitude = mDrops.get(position).getLatitude();
                        Longitude = mDrops.get(position).getLongitude();
                        toaster("Latitude: " + Latitude + " & Longitude: "+ Longitude);
                       addCircleRadius(new LatLng(Latitude, Longitude));
                    }
                }

                else {  //this is the first item selected
                    view.setBackgroundColor(Color.RED);
                    ViewArrays.add(view);
                    Latitude = mDrops.get(position).getLatitude();
                    Longitude = mDrops.get(position).getLongitude();
                    toaster("Latitude: " + Latitude + " & Longitude: "+ Longitude);
                    isSelected = true;
                    addCircleRadius(new LatLng(Latitude, Longitude));
                }
                if(mDrops.get(position).getStatus() == 0){
                    Toast.makeText(DropsActivity.this, "Message: " + mDrops.get(position).getMessage(), Toast.LENGTH_SHORT).show();
                }
                else if(mDrops.get(position).getStatus() == 1){
                    Toast.makeText(DropsActivity.this, "Visit Lat: " + mDrops.get(position).getLatitude()
                            +"\n" + "Long: " + mDrops.get(position).getLongitude(), Toast.LENGTH_SHORT).show();
                }
                else if(mDrops.get(position).getStatus() == 2){
                    Toast.makeText(DropsActivity.this, "Message: " + mDrops.get(position).getMessage(), Toast.LENGTH_SHORT).show();
                }
                toaster(Latitude +" "+ Longitude);
                /*
                for (int i = 0; i <= mDropsAdapter.getItemCount()-1; i++)
                { latlng1 = new LatLng(mDrops.get(i).getLatitude(), mDrops.get(i).getLongitude());
                    Log.d(TAG, "TEST DIS BIH"  + mUID + "/drops/" + mDrops.get(i).getMessageID() + "/status" );              // + latlng1 + " /////" +latlng2);
                    DatabaseReference ref = mRef.child(mUID + "/drops/" + mDrops.get(i).getMessageID());
                    Log.d(TAG, "BEFORE KEY" + ref );
                    String ref2 = ref.getKey();
                    Log.d(TAG, "AFTER KEY" + ref );
                    Log.d(TAG, "latlng1: " + latlng1 + "//////   latlng2: " + latlng2+ "BEFORE" );
                    Log.d(TAG, "Distance: " + distance(latlng1,latlng2) + " BEFORE" );
                    if (distance(latlng1,latlng2) <= STANDARD_RADIUS){
                        Log.d(TAG, "latlng1: " + latlng1 + "//////   latlng2: " + latlng2+ "AFTER" );
                        Log.d(TAG, "TEST SCOREE"  + distance(latlng1,latlng2) + " AFTER" );
                        ref = mRef.child(mUID + "/drops/" + ref2 + "/status");
                        ref.setValue(0);
                        // mDrops.get(i).setStatus(0);
                         //viewHolder.mStatusImage.setImageResource(R.drawable.ic_green_circle);
                    } else{
                        ref = mRef.child(mUID + "/drops/" + ref2 + "/status");
                        ref.setValue(1);
                    }

                }
*/
                moveCamera(new LatLng(Latitude, Longitude), DEFAULT_ZOOM, "Move to Drop Location");
            }

            // calls removeFriend()
            @Override
            public void onDeleteClick(View view, int position) {
                removeDrop(position);
            }
        });
    }


    // listener for changes to user friends on database
    public void setDropsDatabaseListener() {
        Log.d(TAG, "setDropsDatabaseListener(): called");

        mRef.child(mUID + "/drops").orderByChild("status").addValueEventListener(new ValueEventListener() {
            // retrieves drops list from data base when change is detected
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Log.d(TAG, "onDataChange: drops list changed");
                mDrops = new ArrayList<>();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    mDrops.add(snapshot.getValue(Messages.class));
                    Log.d(TAG, "Friend ID: " + snapshot.child("senderID").getValue());
                }
                buildDropsRecyclerView();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void removeDrop(int position){
        mRef.child(mUID + "/drops/" + mDrops.get(position).getMessageID()).removeValue();
    }


    private void openFriendsActivity(){
        Intent intent = new Intent(DropsActivity.this, FriendsActivity.class);
        finish();
        startActivity(intent);
    }

    private void openLocationsActivity(){
        Intent intent = new Intent(DropsActivity.this, LocationsActivity.class);
        finish();
        startActivity(intent);
    }

    private void openProfileActivity(){
        Intent intent = new Intent(DropsActivity.this, ProfileActivity.class);
        finish();
        startActivity(intent);
    }
    private void toaster(String emailToMessage) { // Test to Make sure its the right username
        Toast.makeText(this, emailToMessage, Toast.LENGTH_SHORT).show();
    }
}